# Josy AI Studio

React + TypeScript + Tailwind + Vite. No AI provider is connected by default: generating shows a clear
"not connected" error and records a failed project. Connect providers in `src/services/ai/providers.ts`
(example inside); model slots live in `src/config/models.ts`.

## Windows 11
1. Install Node.js LTS from https://nodejs.org (includes npm), then reopen PowerShell.
2. `cd josy-ai-studio`
3. `npm install`
4. `npm run dev`, then open http://localhost:5173
5. Production build: `npm run build`, then `npm run preview`
If PowerShell blocks npm scripts, use Command Prompt (cmd) instead.
