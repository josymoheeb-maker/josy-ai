// Register real providers here. Example (call your own backend, never ship API keys in the browser):
//
// import { registerProvider } from './registry';
// registerProvider({
//   id: 'image-provider-a', name: 'My image API',
//   async generate(req, signal) {
//     const res = await fetch('/api/generate/image', { method: 'POST', signal,
//       headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(req) });
//     if (!res.ok) throw new Error(`Generation failed (${res.status})`);
//     return res.json(); // { assets: [{ url, kind: 'image' }] }
//   }
// });
export {};
