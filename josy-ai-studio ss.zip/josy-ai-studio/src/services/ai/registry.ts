import type { GenerationRequest, GenerationResult } from '../../types';
import { MODELS } from '../../config/models';

/** Implement this interface to connect a real image/video API. */
export interface GenerationProvider {
  id: string;
  name: string;
  generate(req: GenerationRequest, signal?: AbortSignal): Promise<GenerationResult>;
}
export class ProviderNotConnectedError extends Error {
  constructor(modelLabel: string) {
    super(`${modelLabel} has no provider connected yet. Register a provider in src/services/ai/providers.ts to enable generation.`);
    this.name = 'ProviderNotConnectedError';
  }
}
const providers = new Map<string, GenerationProvider>();
export const registerProvider = (p: GenerationProvider) => providers.set(p.id, p);
export const isModelConnected = (modelId: string) => {
  const m = MODELS.find((x) => x.id === modelId);
  return !!m && providers.has(m.providerId);
};
export async function generate(req: GenerationRequest, signal?: AbortSignal): Promise<GenerationResult> {
  const model = MODELS.find((m) => m.id === req.modelId);
  if (!model) throw new Error('Select a model before generating.');
  const provider = providers.get(model.providerId);
  if (!provider) throw new ProviderNotConnectedError(model.label);
  return provider.generate(req, signal);
}
