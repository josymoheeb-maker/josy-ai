import { Sparkles } from 'lucide-react';
import { NAV } from '../config/tools';
import { useStudio } from '../store/studio';

export default function Sidebar() {
  const { page, go } = useStudio();
  return (
    <aside className="flex w-16 shrink-0 flex-col border-r border-line bg-char md:w-64">
      <div className="flex items-center gap-3 px-4 py-6">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-violet to-silver text-ink"><Sparkles size={18} /></span>
        <span className="hidden font-display text-2xl text-white md:block">Josy AI Studio</span>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-4" aria-label="Main">
        {NAV.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => go(id)} title={label} aria-current={page === id ? 'page' : undefined}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${page === id ? 'bg-violet/15 text-white' : 'text-zinc-400 hover:bg-panel hover:text-white'}`}>
            <Icon size={18} className={page === id ? 'text-violet-soft' : ''} /><span className="hidden md:block">{label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
}
