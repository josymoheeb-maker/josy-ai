import { useRef, useState } from 'react';
import { Sparkles, Square } from 'lucide-react';
import type { AspectRatio, GeneratedAsset, GenerationSettings } from '../types';
import { MODELS } from '../config/models';
import type { ToolDef } from '../config/tools';
import { generate } from '../services/ai/registry';
import { useStudio } from '../store/studio';
import { AspectRatioPicker, EmptyState, ErrorBanner, ImageUpload, Label, LoadingBar, ModelSelect, PageHeader, Panel, Slider } from './ui';
import { AssetGrid } from './ProjectViews';

export default function Workbench({ tool }: { tool: ToolDef }) {
  const { addProject, prefs } = useStudio();
  const models = MODELS.filter((m) => m.kind === tool.kind);
  const [prompt, setPrompt] = useState('');
  const [negative, setNegative] = useState('');
  const [modelId, setModelId] = useState(models[0].id);
  const [aspect, setAspect] = useState<AspectRatio>(prefs.defaultAspect);
  const [refs, setRefs] = useState<string[]>([]);
  const [settings, setSettings] = useState<GenerationSettings>({
    count: 1, seed: null, guidance: 7, steps: 30, duration: 5,
    extra: Object.fromEntries(tool.extra.map((f) => [f.key, f.default]))
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'error'>('idle');
  const [error, setError] = useState('');
  const [assets, setAssets] = useState<GeneratedAsset[]>([]);
  const abort = useRef<AbortController | null>(null);
  const set = (p: Partial<GenerationSettings>) => setSettings((s) => ({ ...s, ...p }));

  const problem = !prompt.trim() ? `Enter a ${tool.promptLabel.toLowerCase()} to continue.`
    : tool.reference === 'required' && refs.length === 0 ? 'Upload a reference image to continue.' : '';

  async function run() {
    setStatus('loading'); setError(''); setAssets([]);
    const ctrl = new AbortController();
    abort.current = ctrl;
    const base = { id: crypto.randomUUID(), tool: tool.id, title: prompt.trim().slice(0, 48), prompt: prompt.trim(), modelId, aspectRatio: aspect, createdAt: Date.now() };
    try {
      const res = await generate({ tool: tool.id, prompt: prompt.trim(), negativePrompt: negative, modelId, aspectRatio: aspect, settings, referenceImages: refs }, ctrl.signal);
      setAssets(res.assets); setStatus('idle');
      addProject({ ...base, status: 'completed', assets: res.assets });
    } catch (e) {
      if (ctrl.signal.aborted) { setStatus('idle'); return; }
      const msg = e instanceof Error ? e.message : 'Generation failed.';
      setError(msg); setStatus('error');
      addProject({ ...base, status: 'failed', error: msg, assets: [] });
    }
  }

  return (
    <div className="animate-rise">
      <PageHeader title={tool.label} blurb={tool.blurb} />
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-5">
          <Panel>
            <Label>{tool.promptLabel}</Label>
            <textarea className="field min-h-[130px] resize-y" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder={tool.placeholder} />
            {tool.kind === 'image' && <div className="mt-4"><Label>Negative prompt (optional)</Label>
              <input className="field" value={negative} onChange={(e) => setNegative(e.target.value)} placeholder="Blurry, extra fingers…" /></div>}
            {tool.maxRefs > 0 && <div className="mt-4"><Label>Reference images {tool.reference === 'required' ? '(required)' : '(optional)'}</Label>
              <ImageUpload images={refs} onChange={setRefs} max={tool.maxRefs} /></div>}
            {tool.extra.length > 0 && <div className="mt-4 grid gap-4 sm:grid-cols-2">{tool.extra.map((f) => (
              <div key={f.key}><Label>{f.label}</Label>
                {f.type === 'select'
                  ? <select className="field" value={String(settings.extra[f.key])} onChange={(e) => set({ extra: { ...settings.extra, [f.key]: e.target.value } })}>{f.options!.map((o) => <option key={o}>{o}</option>)}</select>
                  : <input className="field" type={f.type} value={settings.extra[f.key]} onChange={(e) => set({ extra: { ...settings.extra, [f.key]: f.type === 'number' ? Number(e.target.value) : e.target.value } })} />}
              </div>))}</div>}
            <div className="mt-5 flex flex-wrap items-center gap-3">
              {status === 'loading'
                ? <button className="btn-ghost" onClick={() => abort.current?.abort()}><Square size={14} />Cancel</button>
                : <button className="btn-primary" disabled={!!problem} onClick={run}><Sparkles size={16} />Generate</button>}
              {problem && <span className="text-xs text-zinc-500">{problem}</span>}
            </div>
          </Panel>
          {status === 'loading' && <LoadingBar label="Waiting for the provider…" />}
          {status === 'error' && <ErrorBanner message={error} onClose={() => setStatus('idle')} />}
          {assets.length > 0 ? <AssetGrid assets={assets} aspect={aspect} />
            : status === 'idle' && <EmptyState title="No results yet" hint="Results appear here once a connected model finishes generating." />}
        </div>
        <div className="space-y-5">
          <Panel><Label>Model</Label><ModelSelect models={models} value={modelId} onChange={setModelId} /></Panel>
          <Panel><Label>Aspect ratio</Label><AspectRatioPicker value={aspect} onChange={setAspect} /></Panel>
          <Panel className="space-y-4"><Label>Settings</Label>
            <Slider label={tool.kind === 'video' ? 'Variations' : 'Images'} value={settings.count} min={1} max={4} onChange={(v) => set({ count: v })} />
            {tool.kind === 'video' && <Slider label="Duration (seconds)" value={settings.duration} min={2} max={15} onChange={(v) => set({ duration: v })} />}
            <Slider label="Guidance" value={settings.guidance} min={1} max={20} step={0.5} onChange={(v) => set({ guidance: v })} />
            <Slider label="Steps" value={settings.steps} min={10} max={60} onChange={(v) => set({ steps: v })} />
            <div><Label>Seed (blank for random)</Label>
              <input className="field" type="number" value={settings.seed ?? ''} onChange={(e) => set({ seed: e.target.value === '' ? null : Number(e.target.value) })} /></div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
