import { AlertTriangle, Loader2, Upload, X } from 'lucide-react';
import { useRef, useState, type ReactNode } from 'react';
import type { AspectRatio, ModelInfo } from '../types';
import { isModelConnected } from '../services/ai/registry';

export const PageHeader = ({ title, blurb, action }: { title: string; blurb?: string; action?: ReactNode }) => (
  <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
    <div><h1 className="font-display text-4xl text-white">{title}</h1>{blurb && <p className="mt-1 text-sm text-zinc-400">{blurb}</p>}</div>{action}
  </header>
);
export const Label = ({ children }: { children: ReactNode }) => <label className="mb-1.5 block text-sm text-zinc-400">{children}</label>;
export const Panel = ({ children, className = '' }: { children: ReactNode; className?: string }) => <section className={`rounded-xl border border-line bg-panel p-5 ${className}`}>{children}</section>;
export const ErrorBanner = ({ message, onClose }: { message: string; onClose?: () => void }) => (
  <div role="alert" className="flex items-start gap-3 rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">
    <AlertTriangle size={16} className="mt-0.5 shrink-0" /><p className="flex-1">{message}</p>
    {onClose && <button onClick={onClose} aria-label="Dismiss"><X size={14} /></button>}
  </div>
);
export const EmptyState = ({ title, hint, action }: { title: string; hint: string; action?: ReactNode }) => (
  <div className="flex flex-col items-center rounded-xl border border-dashed border-line p-10 text-center"><p className="text-white">{title}</p><p className="mt-1 max-w-sm text-sm text-zinc-500">{hint}</p>{action && <div className="mt-4">{action}</div>}</div>
);
export const LoadingBar = ({ label }: { label: string }) => (
  <div className="rounded-xl border border-line bg-char p-6" role="status">
    <div className="flex items-center gap-2 text-sm text-white"><Loader2 size={16} className="animate-spin" />{label}</div>
    <div className="mt-4 h-1 overflow-hidden rounded bg-line"><div className="h-full w-1/3 animate-sweep rounded bg-violet" /></div>
  </div>
);

export function ModelSelect({ models, value, onChange }: { models: ModelInfo[]; value: string; onChange: (id: string) => void }) {
  return (
    <div className="grid gap-2">
      {models.map((m) => (
        <button key={m.id} type="button" onClick={() => onChange(m.id)} aria-pressed={value === m.id}
          className={`rounded-lg border p-3 text-left transition ${value === m.id ? 'border-violet bg-violet/10' : 'border-line hover:border-zinc-500'}`}>
          <div className="flex items-center justify-between text-sm text-white">{m.label}
            <span className={`text-xs ${isModelConnected(m.id) ? 'text-emerald-400' : 'text-zinc-500'}`}>{isModelConnected(m.id) ? 'Connected' : 'Not connected'}</span></div>
          <p className="mt-0.5 text-xs text-zinc-500">{m.description}</p>
        </button>
      ))}
    </div>
  );
}

const RATIOS: AspectRatio[] = ['1:1', '16:9', '9:16', '4:3', '3:4', '21:9'];
export function AspectRatioPicker({ value, onChange }: { value: AspectRatio; onChange: (r: AspectRatio) => void }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {RATIOS.map((r) => {
        const [w, h] = r.split(':').map(Number);
        return (
          <button key={r} type="button" onClick={() => onChange(r)} aria-pressed={value === r}
            className={`flex flex-col items-center gap-1.5 rounded-lg border py-2 text-xs transition ${value === r ? 'border-violet text-white' : 'border-line text-zinc-400 hover:border-zinc-500'}`}>
            <span className="block rounded-sm border border-current" style={{ width: 22 * Math.min(1, w / h), height: 22 * Math.min(1, h / w) }} />{r}
          </button>
        );
      })}
    </div>
  );
}

export function ImageUpload({ images, onChange, max }: { images: string[]; onChange: (i: string[]) => void; max: number }) {
  const input = useRef<HTMLInputElement>(null);
  const [err, setErr] = useState('');
  const read = (files: FileList | null) => {
    if (!files) return;
    setErr('');
    const ok = [...files].filter((f) => f.type.startsWith('image/'));
    if (ok.length < files.length) setErr('Only image files can be uploaded.');
    const added: Promise<string>[] = ok.slice(0, max - images.length).filter((f) => {
      if (f.size > 10 * 1024 * 1024) { setErr('Images must be under 10 MB.'); return false; }
      return true;
    }).map((f) => new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = () => rej(); r.readAsDataURL(f); }));
    Promise.all(added).then((urls) => onChange([...images, ...urls])).catch(() => setErr('Could not read that file.'));
  };
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {images.map((src, i) => (
          <div key={i} className="group relative h-20 w-20 overflow-hidden rounded-lg border border-line">
            <img src={src} alt={`Reference ${i + 1}`} className="h-full w-full object-cover" />
            <button type="button" aria-label="Remove image" onClick={() => onChange(images.filter((_, j) => j !== i))}
              className="absolute right-1 top-1 rounded bg-black/70 p-0.5 opacity-0 transition group-hover:opacity-100 focus:opacity-100"><X size={12} /></button>
          </div>
        ))}
        {images.length < max && (
          <button type="button" onClick={() => input.current?.click()}
            onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); read(e.dataTransfer.files); }}
            className="flex h-20 w-20 flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-line text-xs text-zinc-500 transition hover:border-violet hover:text-white">
            <Upload size={16} />Add
          </button>
        )}
      </div>
      <input ref={input} type="file" accept="image/*" multiple={max > 1} hidden onChange={(e) => { read(e.target.files); e.target.value = ''; }} />
      {err && <p className="mt-2 text-xs text-red-300">{err}</p>}
    </div>
  );
}

export function Slider({ label, value, min, max, step = 1, onChange }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void }) {
  return (
    <div><div className="mb-1 flex justify-between text-sm text-zinc-400"><span>{label}</span><span className="text-white">{value}</span></div>
      <input type="range" className="w-full accent-violet" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} /></div>
  );
}
