import { AlertTriangle, Trash2 } from 'lucide-react';
import type { AspectRatio, GeneratedAsset, Project } from '../types';
import { TOOLS } from '../config/tools';
import { useStudio } from '../store/studio';

export function AssetGrid({ assets, aspect }: { assets: GeneratedAsset[]; aspect: AspectRatio }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {assets.map((a, i) => (
        <div key={i} className="overflow-hidden rounded-xl border border-line bg-char" style={{ aspectRatio: aspect.replace(':', ' / ') }}>
          {a.kind === 'video' ? <video src={a.url} controls className="h-full w-full object-cover" /> : <img src={a.url} alt="Generated result" className="h-full w-full object-cover" />}
        </div>
      ))}
    </div>
  );
}

export function ProjectCard({ project }: { project: Project }) {
  const { go, removeProject } = useStudio();
  const tool = TOOLS.find((t) => t.id === project.tool);
  const cover = project.assets[0];
  return (
    <article className="overflow-hidden rounded-xl border border-line bg-panel transition hover:border-violet/60">
      <button className="block w-full text-left" onClick={() => go(project.tool)}>
        <div className="grid aspect-video place-items-center bg-char">
          {cover ? (cover.kind === 'video' ? <video src={cover.url} className="h-full w-full object-cover" /> : <img src={cover.url} alt="" className="h-full w-full object-cover" />)
            : <span className="flex items-center gap-2 px-4 text-center text-xs text-red-300"><AlertTriangle size={14} />Not generated</span>}
        </div>
        <div className="p-3">
          <p className="truncate text-sm text-white">{project.title || 'Untitled'}</p>
          <p className="mt-0.5 text-xs text-zinc-500">{tool?.label} · {new Date(project.createdAt).toLocaleString()}</p>
          {project.status === 'failed' && <p className="mt-1 line-clamp-2 text-xs text-red-300">{project.error}</p>}
        </div>
      </button>
      <div className="flex justify-end border-t border-line px-3 py-1.5">
        <button onClick={() => removeProject(project.id)} className="flex items-center gap-1 text-xs text-zinc-500 transition hover:text-red-300"><Trash2 size={12} />Delete</button>
      </div>
    </article>
  );
}
