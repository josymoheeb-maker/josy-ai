import { useState } from 'react';
import { ArrowDown, ArrowUp, Trash2 } from 'lucide-react';
import { EmptyState, Label, PageHeader, Panel } from '../components/ui';
import { ProjectCard } from '../components/ProjectViews';
import { NAV, TOOLS } from '../config/tools';
import { MODELS } from '../config/models';
import { isModelConnected } from '../services/ai/registry';
import { useStudio } from '../store/studio';
import type { AspectRatio, GeneratedAsset } from '../types';

export function Dashboard() {
  const { projects, go } = useStudio();
  return (
    <div className="animate-rise">
      <PageHeader title="Good to see you" blurb="Start something new or pick up a recent project." />
      <div className="mb-10 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {TOOLS.map((t) => { const Icon = NAV.find((n) => n.id === t.id)!.icon; return (
          <button key={t.id} onClick={() => go(t.id)} className="rounded-xl border border-line bg-panel p-4 text-left transition hover:border-violet">
            <Icon size={20} className="text-violet-soft" /><p className="mt-3 text-sm text-white">{t.label}</p><p className="mt-1 text-xs text-zinc-500">{t.blurb}</p>
          </button>); })}
      </div>
      <h2 className="mb-4 font-display text-2xl text-white">Recent projects</h2>
      {projects.length === 0 ? <EmptyState title="No projects yet" hint="Every generation attempt is saved here, including ones that fail." />
        : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{projects.slice(0, 8).map((p) => <ProjectCard key={p.id} project={p} />)}</div>}
    </div>
  );
}

export function LibraryPage() {
  const { projects, clearProjects } = useStudio();
  const [filter, setFilter] = useState<'all' | 'completed' | 'failed'>('all');
  const list = projects.filter((p) => filter === 'all' || p.status === filter);
  return (
    <div className="animate-rise">
      <PageHeader title="My Library" blurb="Project history and generated media." />
      <div className="mb-5 flex flex-wrap gap-2">{(['all', 'completed', 'failed'] as const).map((f) => (
        <button key={f} onClick={() => setFilter(f)} className={`rounded-full border px-3 py-1 text-sm capitalize transition ${filter === f ? 'border-violet text-white' : 'border-line text-zinc-400'}`}>{f}</button>))}
        {projects.length > 0 && <button className="btn-ghost ml-auto" onClick={() => confirm('Delete all project history?') && clearProjects()}>Clear history</button>}
      </div>
      {list.length === 0 ? <EmptyState title="Nothing here" hint="Completed generations and failed attempts will be listed here." />
        : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{list.map((p) => <ProjectCard key={p.id} project={p} />)}</div>}
    </div>
  );
}

export function EditorPage() {
  const { projects, go } = useStudio();
  const clips = projects.flatMap((p) => p.assets.filter((a) => a.kind === 'video'));
  const [timeline, setTimeline] = useState<GeneratedAsset[]>([]);
  const move = (i: number, d: number) => setTimeline((t) => { const n = [...t]; const j = i + d; if (j < 0 || j >= n.length) return t; [n[i], n[j]] = [n[j], n[i]]; return n; });
  return (
    <div className="animate-rise">
      <PageHeader title="Video Editor" blurb="Arrange generated clips into a sequence." />
      {clips.length === 0 ? <EmptyState title="No clips to edit" hint="Generated videos from your library show up here." action={<button className="btn-primary" onClick={() => go('video')}>Generate a video</button>} /> : (
        <div className="grid gap-6 lg:grid-cols-2">
          <Panel><Label>Library clips</Label><div className="space-y-2">{clips.map((c, i) => (
            <div key={i} className="flex items-center gap-3"><video src={c.url} className="h-14 w-24 rounded object-cover" />
              <button className="btn-ghost ml-auto" onClick={() => setTimeline((t) => [...t, c])}>Add to timeline</button></div>))}</div></Panel>
          <Panel><Label>Timeline</Label>
            {timeline.length === 0 ? <p className="text-sm text-zinc-500">Add clips to build a sequence.</p> : timeline.map((c, i) => (
              <div key={i} className="mb-2 flex items-center gap-2"><video src={c.url} className="h-12 w-20 rounded object-cover" /><span className="text-sm text-white">Clip {i + 1}</span>
                <div className="ml-auto flex gap-1"><button aria-label="Move up" className="btn-ghost px-2" onClick={() => move(i, -1)}><ArrowUp size={14} /></button>
                  <button aria-label="Move down" className="btn-ghost px-2" onClick={() => move(i, 1)}><ArrowDown size={14} /></button>
                  <button aria-label="Remove" className="btn-ghost px-2" onClick={() => setTimeline((t) => t.filter((_, j) => j !== i))}><Trash2 size={14} /></button></div></div>))}
            <button className="btn-primary mt-3" disabled>Export</button>
            <p className="mt-2 text-xs text-zinc-500">Exporting needs a rendering backend, which is not connected.</p></Panel>
        </div>)}
    </div>
  );
}

export function SettingsPage() {
  const { prefs, setPrefs, clearProjects } = useStudio();
  return (
    <div className="animate-rise max-w-2xl space-y-5">
      <PageHeader title="Settings" />
      <Panel><Label>Default aspect ratio</Label>
        <select className="field" value={prefs.defaultAspect} onChange={(e) => setPrefs({ defaultAspect: e.target.value as AspectRatio })}>
          {['1:1', '16:9', '9:16', '4:3', '3:4', '21:9'].map((r) => <option key={r}>{r}</option>)}</select></Panel>
      <Panel><Label>Provider status</Label><ul className="space-y-1.5 text-sm">{MODELS.map((m) => (
        <li key={m.id} className="flex justify-between"><span className="text-white">{m.label}</span>
          <span className={isModelConnected(m.id) ? 'text-emerald-400' : 'text-zinc-500'}>{isModelConnected(m.id) ? 'Connected' : 'Not connected'}</span></li>))}</ul>
        <p className="mt-3 text-xs text-zinc-500">Connect providers in src/services/ai/providers.ts. Keep API keys on a server, not in this app.</p></Panel>
      <Panel><Label>Data</Label><button className="btn-ghost" onClick={() => confirm('Delete all project history?') && clearProjects()}>Clear project history</button></Panel>
    </div>
  );
}
