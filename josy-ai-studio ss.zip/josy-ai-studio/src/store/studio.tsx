import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AspectRatio, PageId, Project } from '../types';

interface Prefs { defaultAspect: AspectRatio }
interface Ctx {
  page: PageId; go: (p: PageId) => void;
  projects: Project[]; addProject: (p: Project) => void; removeProject: (id: string) => void; clearProjects: () => void;
  prefs: Prefs; setPrefs: (p: Prefs) => void;
}
const StudioCtx = createContext<Ctx | null>(null);
const load = <T,>(k: string, fallback: T): T => { try { return JSON.parse(localStorage.getItem(k) ?? '') as T; } catch { return fallback; } };
const save = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage full or blocked */ } };
const fromHash = (): PageId => (location.hash.slice(1) || 'dashboard') as PageId;

export function StudioProvider({ children }: { children: ReactNode }) {
  const [page, setPage] = useState<PageId>(fromHash);
  const [projects, setProjects] = useState<Project[]>(() => load('josy.projects', []));
  const [prefs, setPrefs] = useState<Prefs>(() => load('josy.prefs', { defaultAspect: '16:9' }));
  useEffect(() => { const f = () => setPage(fromHash()); addEventListener('hashchange', f); return () => removeEventListener('hashchange', f); }, []);
  useEffect(() => save('josy.projects', projects), [projects]);
  useEffect(() => save('josy.prefs', prefs), [prefs]);
  const go = useCallback((p: PageId) => { location.hash = p; }, []);
  const value = useMemo<Ctx>(() => ({
    page, go, projects, prefs, setPrefs,
    addProject: (p) => setProjects((x) => [p, ...x].slice(0, 200)),
    removeProject: (id) => setProjects((x) => x.filter((p) => p.id !== id)),
    clearProjects: () => setProjects([])
  }), [page, go, projects, prefs]);
  return <StudioCtx.Provider value={value}>{children}</StudioCtx.Provider>;
}
export const useStudio = () => { const c = useContext(StudioCtx); if (!c) throw new Error('StudioProvider missing'); return c; };
