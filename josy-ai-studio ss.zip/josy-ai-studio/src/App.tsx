import Sidebar from './components/Sidebar';
import Workbench from './components/Workbench';
import { TOOLS } from './config/tools';
import { Dashboard, EditorPage, LibraryPage, SettingsPage } from './pages/Pages';
import { useStudio } from './store/studio';

export default function App() {
  const { page } = useStudio();
  const tool = TOOLS.find((t) => t.id === page);
  return (
    <div className="flex h-full">
      <Sidebar />
      <main className="flex-1 overflow-y-auto bg-gradient-to-b from-char/40 to-ink p-6 md:p-10">
        {tool ? <Workbench key={tool.id} tool={tool} />
          : page === 'library' ? <LibraryPage /> : page === 'editor' ? <EditorPage /> : page === 'settings' ? <SettingsPage /> : <Dashboard />}
      </main>
    </div>
  );
}
