import type { ModelInfo } from '../types';
// Model slots. Each points at a providerId; connect a real provider with that id in services/ai/providers.ts.
export const MODELS: ModelInfo[] = [
  { id: 'image-a', label: 'Image model A', kind: 'image', providerId: 'image-provider-a', description: 'Slot for your primary text-to-image model.' },
  { id: 'image-b', label: 'Image model B', kind: 'image', providerId: 'image-provider-b', description: 'Slot for a faster, lower-cost image model.' },
  { id: 'video-a', label: 'Video model A', kind: 'video', providerId: 'video-provider-a', description: 'Slot for your primary video model.' },
  { id: 'video-b', label: 'Video model B', kind: 'video', providerId: 'video-provider-b', description: 'Slot for an image-to-video model.' }
];
