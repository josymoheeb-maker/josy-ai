import { Image, Video, Film, UserSquare, Users, BookOpen, Megaphone, Scissors, Library, Settings, LayoutDashboard } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { MediaKind, PageId, ToolId } from '../types';

export interface ExtraField { key: string; label: string; type: 'text' | 'number' | 'select'; options?: string[]; default: string | number }
export interface ToolDef {
  id: ToolId; label: string; kind: MediaKind; blurb: string; promptLabel: string; placeholder: string;
  reference: 'none' | 'optional' | 'required'; maxRefs: number; extra: ExtraField[];
}
export const TOOLS: ToolDef[] = [
  { id: 'image', label: 'Image Generation', kind: 'image', blurb: 'Create images from a written description.', promptLabel: 'Prompt', placeholder: 'A lighthouse on a basalt cliff at dusk, long exposure…', reference: 'optional', maxRefs: 3, extra: [] },
  { id: 'video', label: 'Video Generation', kind: 'video', blurb: 'Create short clips from a written description.', promptLabel: 'Prompt', placeholder: 'Slow dolly through a rain-soaked neon market…', reference: 'none', maxRefs: 0, extra: [{ key: 'motion', label: 'Camera motion', type: 'select', options: ['Static', 'Pan', 'Dolly', 'Orbit', 'Handheld'], default: 'Dolly' }] },
  { id: 'image-to-video', label: 'Image to Video', kind: 'video', blurb: 'Animate a still image.', promptLabel: 'Motion prompt', placeholder: 'Hair moves in the wind, camera pushes in slowly…', reference: 'required', maxRefs: 1, extra: [{ key: 'motionStrength', label: 'Motion strength (1-10)', type: 'number', default: 5 }] },
  { id: 'character', label: 'Character Studio', kind: 'image', blurb: 'Design characters from a description and references.', promptLabel: 'Character description', placeholder: 'Silver-haired cartographer, weathered coat, calm expression…', reference: 'optional', maxRefs: 4, extra: [{ key: 'view', label: 'View', type: 'select', options: ['Portrait', 'Full body', 'Turnaround sheet', 'Expression sheet'], default: 'Portrait' }] },
  { id: 'consistency', label: 'Character Consistency', kind: 'image', blurb: 'Keep one character identical across new scenes.', promptLabel: 'New scene', placeholder: 'She reads a map in a train station at dawn…', reference: 'required', maxRefs: 4, extra: [{ key: 'identity', label: 'Identity strength (1-10)', type: 'number', default: 8 }] },
  { id: 'story', label: 'AI Story Maker', kind: 'image', blurb: 'Turn a premise into illustrated scenes.', promptLabel: 'Story premise', placeholder: 'A lighthouse keeper discovers the light calls something back…', reference: 'optional', maxRefs: 2, extra: [{ key: 'scenes', label: 'Scenes', type: 'number', default: 6 }, { key: 'style', label: 'Visual style', type: 'select', options: ['Cinematic', 'Storybook', 'Graphic novel', 'Watercolor'], default: 'Cinematic' }] },
  { id: 'ads', label: 'AI Ads Creator', kind: 'video', blurb: 'Make product ads from a brief.', promptLabel: 'Product brief', placeholder: 'Matte-black thermos, outdoor audience, calm and confident…', reference: 'optional', maxRefs: 3, extra: [{ key: 'platform', label: 'Platform', type: 'select', options: ['Instagram Reels', 'TikTok', 'YouTube Shorts', 'Web banner'], default: 'Instagram Reels' }, { key: 'tone', label: 'Tone', type: 'text', default: 'Confident' }] }
];
export const NAV: { id: PageId; label: string; icon: LucideIcon }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'image', label: 'Image Generation', icon: Image },
  { id: 'video', label: 'Video Generation', icon: Video },
  { id: 'image-to-video', label: 'Image to Video', icon: Film },
  { id: 'character', label: 'Character Studio', icon: UserSquare },
  { id: 'consistency', label: 'Character Consistency', icon: Users },
  { id: 'story', label: 'AI Story Maker', icon: BookOpen },
  { id: 'ads', label: 'AI Ads Creator', icon: Megaphone },
  { id: 'editor', label: 'Video Editor', icon: Scissors },
  { id: 'library', label: 'My Library', icon: Library },
  { id: 'settings', label: 'Settings', icon: Settings }
];
