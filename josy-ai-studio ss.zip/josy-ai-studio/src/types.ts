export type ToolId = 'image' | 'video' | 'image-to-video' | 'character' | 'consistency' | 'story' | 'ads';
export type PageId = 'dashboard' | ToolId | 'editor' | 'library' | 'settings';
export type MediaKind = 'image' | 'video';
export type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '21:9';
export interface ModelInfo { id: string; label: string; kind: MediaKind; providerId: string; description: string }
export interface GenerationSettings { count: number; seed: number | null; guidance: number; steps: number; duration: number; extra: Record<string, string | number> }
export interface GenerationRequest {
  tool: ToolId; prompt: string; negativePrompt: string; modelId: string; aspectRatio: AspectRatio;
  settings: GenerationSettings; referenceImages: string[]; // data URLs
}
export interface GeneratedAsset { url: string; kind: MediaKind }
export interface GenerationResult { assets: GeneratedAsset[] }
export interface Project {
  id: string; tool: ToolId; title: string; prompt: string; modelId: string; aspectRatio: AspectRatio;
  status: 'completed' | 'failed'; error?: string; createdAt: number; assets: GeneratedAsset[];
}
