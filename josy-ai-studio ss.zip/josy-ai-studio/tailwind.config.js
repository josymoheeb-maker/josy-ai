export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { ink: '#0c0b0f', char: '#17161c', panel: '#1f1d26', line: '#2d2a38', violet: { DEFAULT: '#8b6df0', soft: '#b7a2ff' }, silver: '#c9ccd6' },
    fontFamily: { display: ['"Instrument Serif"', 'Georgia', 'serif'], sans: ['"Inter Tight"', 'system-ui', 'sans-serif'] },
    keyframes: { rise: { from: { opacity: '0', transform: 'translateY(6px)' }, to: { opacity: '1', transform: 'none' } }, sweep: { from: { transform: 'translateX(-100%)' }, to: { transform: 'translateX(250%)' } } },
    animation: { rise: 'rise .35s ease-out', sweep: 'sweep 1.4s ease-in-out infinite' }
  } },
  plugins: []
};
